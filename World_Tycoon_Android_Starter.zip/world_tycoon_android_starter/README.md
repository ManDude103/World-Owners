# World Tycoon — Android starter

This is a playable web-game starter with local autosaves, an 8-hour offline earnings cap, optional Firebase email/password accounts, and a Capacitor Android wrapper.

## Run the game on a computer
1. Install Node.js (LTS).
2. Extract this folder.
3. Open a terminal in this folder and run:
   - `npm install`
   - `npm run dev`
4. Open the local Vite address shown in the terminal.

## Local saves
Guest progress is stored in the browser/device using `localStorage`. Autosaves occur during play, on important game actions, when the app is backgrounded, and when it closes. Clearing app storage or uninstalling can erase a guest save.

## Enable optional cloud saves
1. Create a Firebase project at https://console.firebase.google.com/ (a parent/guardian can help).
2. Add a Web App in Firebase project settings.
3. Enable Authentication > Sign-in method > Email/Password.
4. Create a Firestore database.
5. Paste the Firebase web app config into `src/firebase.js` (replace the PASTE_ values).
6. Publish the rules in `firestore.rules` in Firebase Console.
7. Run `npm run dev` and test account creation, login, cloud restore, and account deletion.

Cloud backup is optional. Without Firebase configuration, guest/local saves still work. Do not place Firebase Admin SDK credentials in this app.

## Build the Android project
1. Install Android Studio and its Android SDK.
2. Run `npm install`.
3. Run `npx cap add android` once.
4. Run `npm run android:sync`.
5. Run `npm run android:open` to open the native project in Android Studio.
6. Test on a real Android phone.
7. For a Play Store release, use Android Studio's signed Android App Bundle (AAB) build workflow.

The Android app id is `com.worldtycoon.game`; change it before the first release if you want a different permanent package id.

## Important release notes
- This starter is a foundation, not a finished commercial release.
- The map is a stylized overview, not a detailed political map.
- The game currently uses client-side offline time for a casual single-player experience. A competitive economy would need server-authoritative time and validation.
- Review Google Play's current testing, privacy, Data safety, and account deletion requirements before release.
- A Google Play developer account has a registration fee; this project does not bypass it.
