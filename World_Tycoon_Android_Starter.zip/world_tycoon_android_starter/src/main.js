import "./style.css";
import { cloudReady, createAccount, login, logout, currentUser,
  readCloudSave, writeCloudSave, removeCloudAccount } from "./firebase.js";

const KEY = "worldTycoonSaveV1";
const MAX_OFFLINE = 8 * 60 * 60;
const countries = [
  ["USA","Americas",600],["Canada","Americas",420],["Brazil","Americas",350],
  ["Greece","Europe",220],["France","Europe",320],["Germany","Europe",400],
  ["Egypt","Africa",180],["Nigeria","Africa",260],["South Africa","Africa",340],
  ["China","Asia",500],["India","Asia",380],["Japan","Asia",460]
];
const businesses = [
  ["Village Market",150,2,1],["Trading Company",600,5,4],
  ["Merchant Fleet",1800,12,12],["Royal Bank",5000,30,35]
];
const fresh = () => ({
  money:250, manualClickValue:1, manualLevel:0, autoLevel:0,
  ownedCountries:[], ownedBusinesses:[], lastSavedAt:Date.now()
});
let game = fresh(), tab = "home", notice = "", cloudBusy = false;

const fmt = n => Math.floor(n).toLocaleString("en-US");
const businessBonus = () => game.ownedBusinesses.reduce((a,id)=>{
  const b=businesses[id]; return {click:a.click+b[2],cps:a.cps+b[3]};
},{click:0,cps:0});
const clickValue = () => game.manualClickValue + businessBonus().click + game.ownedCountries.length*2;
const cps = () => game.autoLevel*5 + businessBonus().cps + game.ownedCountries.length;
function snapshot() {
  return {...game, version:1, lastSavedAt:Date.now()};
}
function localSave() {
  try { localStorage.setItem(KEY, JSON.stringify(snapshot())); return true; }
  catch(e) { console.error(e); notice="Save failed — device storage may be full."; return false; }
}
function readLocal() {
  try {
    const s=JSON.parse(localStorage.getItem(KEY)||"null");
    if (!s || s.version!==1 || !Number.isFinite(s.money)) return null;
    return {...fresh(), ...s,
      ownedCountries:Array.isArray(s.ownedCountries)?s.ownedCountries:[],
      ownedBusinesses:Array.isArray(s.ownedBusinesses)?s.ownedBusinesses:[]};
  } catch { return null; }
}
function applySave(s) {
  if (!s) return 0;
  const elapsed=Math.max(0,(Date.now()-(s.lastSavedAt||Date.now()))/1000);
  const seconds=Math.min(MAX_OFFLINE,elapsed);
  game={...fresh(),...s};
  const earnings=Math.floor(seconds*cps());
  game.money+=earnings;
  game.lastSavedAt=Date.now();
  localSave();
  return earnings;
}
function persist(syncCloud=true) {
  game.lastSavedAt=Date.now();
  localSave();
  const user=currentUser();
  if (syncCloud && user && cloudReady) {
    const data=snapshot();
    writeCloudSave(user.uid,data).catch(e=>{console.error(e); notice="Cloud sync failed. Your device save is safe."; render();});
  }
}
function earnClick(){game.money+=clickValue(); persist(); render();}
function buyCountry(i){
  const c=countries[i]; if(game.ownedCountries.includes(i)||game.money<c[2]) return;
  game.money-=c[2]; game.ownedCountries.push(i); persist(); notice=`${c[0]} joined your empire!`; render();
}
function buyBusiness(i){
  const b=businesses[i]; if(game.ownedBusinesses.includes(i)||game.money<b[1]) return;
  game.money-=b[1]; game.ownedBusinesses.push(i); persist(); notice=`${b[0]} acquired!`; render();
}
function buyManual(){
  const cost=100+game.manualLevel*100; if(game.money<cost)return;
  game.money-=cost; game.manualLevel++; game.manualClickValue++; persist(); render();
}
function buyAuto(){
  const cost=(game.autoLevel+1)*250; if(game.money<cost)return;
  game.money-=cost; game.autoLevel++; persist(); render();
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function button(label, action, disabled=false, cls="") {
  return `<button class="${cls}" data-action="${action}" ${disabled?"disabled":""}>${label}</button>`;
}
function render(){
 const app=document.querySelector("#app");
 const owned=game.ownedCountries.length, bbonus=businessBonus();
 const countryRows=countries.map((c,i)=>`<article class="item">
   <div><b>${c[0]}</b><small>${c[1]} · +2 Æ/click · +1 Æ/sec</small></div>
   ${game.ownedCountries.includes(i)?'<span class="owned">OWNED</span>':button(`Buy · ${fmt(c[2])} Æ`,`country:${i}`,game.money<c[2])}
 </article>`).join("");
 const businessRows=businesses.map((b,i)=>`<article class="item">
   <div><b>${b[0]}</b><small>+${b[2]} Æ/click · +${b[3]} Æ/sec</small></div>
   ${game.ownedBusinesses.includes(i)?'<span class="owned">OWNED</span>':button(`Buy · ${fmt(b[1])} Æ`,`business:${i}`,game.money<b[1])}
 </article>`).join("");
 const manualCost=100+game.manualLevel*100, autoCost=(game.autoLevel+1)*250;
 app.innerHTML=`
 <header><div class="brand">WORLD <span>TYCOON</span></div><div class="sub">THE GOLDEN EMPIRE</div>
 <div class="balance">${fmt(game.money)} <span>Æ</span></div><small class="muted">TREASURY</small></header>
 <nav>${["home","upgrades","businesses","empire"].map(t=>`<button data-tab="${t}" class="${tab===t?"active":""}">${t.toUpperCase()}</button>`).join("")}</nav>
 ${notice?`<div class="notice">${esc(notice)} <button data-action="dismiss">×</button></div>`:""}
 <main>
 ${tab==="home"?`
  <section class="hero"><div><small>YOUR EMPIRE</small><h1>Build your legacy.</h1>
  <p>Every tap builds your golden fortune.</p></div>
  <div class="stats"><div><b>${fmt(clickValue())} Æ</b><small>PER TAP</small></div><div><b>${fmt(cps())} Æ</b><small>PER SECOND</small></div></div></section>
  <button class="mint" data-action="mint">MINT AUREON <strong>+${fmt(clickValue())} Æ</strong></button>
  <section class="panel"><h2>WORLD CONTROL</h2><div class="map">
   <div class="land land1 ${owned>=3?"gold":""}">AMERICAS</div>
   <div class="land land2 ${owned>=6?"gold":""}">EUROPE</div>
   <div class="land land3 ${owned>=9?"gold":""}">AFRICA</div>
   <div class="land land4 ${owned>=12?"gold":""}">ASIA</div>
   <span class="mapcaption">YOUR TERRITORY GROWS WITH EVERY ACQUISITION</span>
  </div><p class="muted">${owned}/12 countries controlled · ${game.ownedBusinesses.length}/4 businesses owned</p></section>`:""}
 ${tab==="upgrades"?`<section class="panel"><h1>Upgrades</h1>
  <article class="item"><div><b>Master Minting</b><small>Increase manual clicks by +1 · Level ${game.manualLevel}</small></div>${button(`Upgrade · ${fmt(manualCost)} Æ`,"manual",game.money<manualCost)}</article>
  <article class="item"><div><b>Automated Treasury</b><small>Increase passive income by +5 Æ/sec · Level ${game.autoLevel}</small></div>${button(`Upgrade · ${fmt(autoCost)} Æ`,"auto",game.money<autoCost)}</article>
 </section>`:""}
 ${tab==="businesses"?`<section class="panel"><h1>Businesses</h1><p class="muted">Businesses boost both your tapping power and passive income.</p>${businessRows}</section>`:""}
 ${tab==="empire"?`<section class="panel"><h1>Empire Expansion</h1><p class="muted">Acquire countries to increase clicks and income.</p>${countryRows}</section>`:""}
 <section class="panel account"><h2>ACCOUNT & SAVES</h2>
 <p class="muted">${currentUser()?`Cloud backup connected: ${esc(currentUser().email)}`:"Guest mode · Saved on this device"} </p>
 ${!currentUser()?`<div class="auth"><input id="email" type="email" placeholder="Email address" autocomplete="email"><input id="password" type="password" placeholder="Password (6+ characters)" autocomplete="current-password"><div class="actions">${button("CREATE ACCOUNT","signup")}${button("LOG IN","login",false,"secondary")}</div></div>`:
 `${button("SYNC CLOUD SAVE","sync")}${button("SIGN OUT","logout",false,"secondary")} ${button("DELETE ACCOUNT & CLOUD SAVE","deleteAccount",false,"danger")}`}
 <small class="muted">${cloudReady?"Optional cloud backup is configured.":"Cloud backup needs Firebase project settings; guest device saves already work."}</small>
 </section>
 </main><footer>WORLD TYCOON · Æ AUREON · AUTOSAVE ON</footer>`;
}
document.addEventListener("click",async e=>{
 const t=e.target.closest("button"); if(!t)return;
 if(t.dataset.tab){tab=t.dataset.tab;render();return;}
 const a=t.dataset.action;if(!a)return;
 if(a==="dismiss"){notice="";render();return;}
 if(a==="mint"){earnClick();return;}
 if(a.startsWith("country:")){buyCountry(+a.split(":")[1]);return;}
 if(a.startsWith("business:")){buyBusiness(+a.split(":")[1]);return;}
 if(a==="manual"){buyManual();return;} if(a==="auto"){buyAuto();return;}
 if(a==="signup"||a==="login"){
  const email=document.querySelector("#email")?.value.trim(), password=document.querySelector("#password")?.value;
  if(!email||!password){notice="Enter an email and password.";render();return;}
  if(!cloudReady){notice="Cloud backup isn't configured yet. Device saves still work.";render();return;}
  try{
   cloudBusy=true;
   const cred=a==="signup"?await createAccount(email,password):await login(email,password);
   const cloud=await readCloudSave(cred.user.uid), local=readLocal();
   const chosen=cloud&&(!local||((cloud.lastSavedAt||0)>(local.lastSavedAt||0)))?cloud:local;
   if(chosen){const gained=applySave(chosen); notice=`Progress restored. Offline earnings: ${fmt(gained)} Æ.`;}
   else {persist();notice="Account created. Cloud backup is on.";}
  }catch(err){notice=err.message||"Account sign-in failed.";}
  finally{cloudBusy=false;render();}return;
 }
 if(a==="sync"){
  const user=currentUser();if(user){try{await writeCloudSave(user.uid,snapshot());notice="Cloud save synced.";}catch{notice="Cloud sync failed.";}}render();return;
 }
 if(a==="logout"){await logout();notice="Signed out. Your device save remains.";render();return;}
 if(a==="deleteAccount"){
  if(!confirm("Delete your cloud account and cloud save? Your local device save will remain."))return;
  try{await removeCloudAccount();notice="Cloud account and save deleted.";}catch(err){notice=err.message||"Deletion failed. You may need to sign in again."; }render();return;
 }
});
const previous=readLocal();
if(previous){
 const gained=applySave(previous);
 if(gained>0)notice=`Welcome back! Your empire earned ${fmt(gained)} Æ while you were away.`;
}else{localSave();}
render();
let lastCloudSync=Date.now();
setInterval(()=>{
  game.money+=cps();
  persist(false);
  if(Date.now()-lastCloudSync>=60000 && currentUser() && cloudReady){
    lastCloudSync=Date.now();
    writeCloudSave(currentUser().uid,snapshot()).catch(e=>console.error("Cloud sync failed",e));
  }
  if(tab==="home")render();
},1000);
document.addEventListener("visibilitychange",()=>{if(document.hidden)persist();});
window.addEventListener("pagehide",()=>persist());
