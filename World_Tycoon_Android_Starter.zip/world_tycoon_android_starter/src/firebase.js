// Optional cloud backup. Create a Firebase project, enable Email/Password
// Authentication and Firestore, then paste your web app config below.
// Never put service-account/private admin keys in this client app.
import { initializeApp } from "firebase/app";
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, deleteUser
} from "firebase/auth";
import {
  getFirestore, doc, getDoc, setDoc, deleteDoc, serverTimestamp
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_WEB_API_KEY",
  authDomain: "PASTE_PROJECT.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  appId: "PASTE_FIREBASE_APP_ID"
};

export const cloudReady = !Object.values(firebaseConfig).some(v => String(v).startsWith("PASTE_"));
let auth = null, db = null;
if (cloudReady) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
}

export async function createAccount(email, password) {
  if (!cloudReady) throw new Error("Cloud backup is not configured yet.");
  return createUserWithEmailAndPassword(auth, email, password);
}
export async function login(email, password) {
  if (!cloudReady) throw new Error("Cloud backup is not configured yet.");
  return signInWithEmailAndPassword(auth, email, password);
}
export async function logout() {
  if (auth) await signOut(auth);
}
export function currentUser() { return auth?.currentUser || null; }

export async function readCloudSave(uid) {
  const snap = await getDoc(doc(db, "playerSaves", uid));
  return snap.exists() ? snap.data().save : null;
}
export async function writeCloudSave(uid, save) {
  await setDoc(doc(db, "playerSaves", uid), {
    save, updatedAt: serverTimestamp()
  });
}
export async function removeCloudAccount() {
  const user = auth?.currentUser;
  if (!user) return;
  await deleteDoc(doc(db, "playerSaves", user.uid));
  await deleteUser(user);
}
